<div>
    <h2>Component {{ $userCount }}</h2>
    <!-- Happiness is not something readymade. It comes from your own actions. - Dalai Lama -->
</div>
