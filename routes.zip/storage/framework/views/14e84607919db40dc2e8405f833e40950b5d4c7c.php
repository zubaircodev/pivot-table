<div>
    <h2>Component <?php echo e($userCount); ?></h2>
    <!-- Happiness is not something readymade. It comes from your own actions. - Dalai Lama -->
</div>
<?php /**PATH C:\laragon\www\new\resources\views/components/user-follow.blade.php ENDPATH**/ ?>