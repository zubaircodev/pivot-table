<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>



                        <?php if (isset($component)) { $__componentOriginala40bc942375466b1b06a297c24d22580f2c94ec3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserFollow::class, []); ?>
<?php $component->withName('user-follow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40bc942375466b1b06a297c24d22580f2c94ec3)): ?>
<?php $component = $__componentOriginala40bc942375466b1b06a297c24d22580f2c94ec3; ?>
<?php unset($__componentOriginala40bc942375466b1b06a297c24d22580f2c94ec3); ?>
<?php endif; ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>User</th>
                            <th>email</th>
                            <th>Following</th>
                            <th>Following</th>
                            <th>action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = \App\Models\User::with('following')->where('id', '!=', auth()->user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->following->count()); ?></td>
                                <td><?php echo e($user->follower->count()); ?></td>
                                <td><?php echo e(''); ?></td>
                                <td>
                                    <?php if(auth()->user()->following->contains($user->id)): ?>
                                    <a class="btn btn-primary" href="<?php echo e(route('user.follow', $user->id)); ?>">Un-Follow</a>
                                    <?php else: ?>
                                        <a class="btn btn-primary" href="<?php echo e(route('user.follow', $user->id)); ?>">Follow</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new\resources\views/home.blade.php ENDPATH**/ ?>